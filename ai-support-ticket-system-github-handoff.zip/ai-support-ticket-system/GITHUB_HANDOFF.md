# GitHub handoff instructions

## What this repository contains

This repository contains the DistilBERT AI service under `backend/app/ai/`. It includes PII redaction, a shared DistilBERT encoder, category and priority classification heads, an optional sentiment head, confidence thresholds, human-review flags, dataset normalization, training, inference, and a FastAPI endpoint.

The repository does **not** contain trained weights by default. The recipient must train the model using approved de-identified data or receive the model artifact through a private artifact store.

## What to commit

Commit the source code, `backend/requirements.txt`, `Dockerfile`, `COLAB_ONE_CELL.py`, `COLAB_COPY_PASTE.md`, `DATASET_REPORT.md`, and the project documentation. Do not commit `.env` files, API keys, raw customer data, or trained model weights to a public repository. The included `.gitignore` excludes these items.

If the two uploaded datasets are legally approved for repository storage, keep them in a private repository only. Otherwise, transfer them through a secure private channel and place them under `data/uploads/` locally.

## Recipient setup

```bash
git clone <REPOSITORY_URL>
cd ai-support-ticket-system
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
```

Place the approved datasets in the project root or update the paths in the preparation command. The expected raw files are `tickets.json` and `support_tickets(1).json`.

## Prepare the combined dataset

```bash
python -m backend.app.ai.prepare_data \
  --tickets tickets.json \
  --support-tickets 'support_tickets(1).json' \
  --banking77-dir data/banking77 \
  --add-banking77 \
  --output-dir data/combined
```

The preparation script namespaces categories by source, removes duplicate text records, creates a category-stratified split, and never fabricates missing priority or sentiment labels.

## Train the model

```bash
python -m backend.app.ai.train \
  --train-file data/combined/train.jsonl \
  --eval-file data/combined/valid.jsonl \
  --output-dir backend/app/ai/model_artifacts \
  --epochs 3 \
  --train-batch-size 16 \
  --eval-batch-size 16 \
  --max-length 256
```

Training must finish successfully and create `config.json`, model weights, tokenizer files, `ticket_config.json`, and `label_maps.json` in `backend/app/ai/model_artifacts/`.

## Run the API

```bash
export MODEL_DIR=backend/app/ai/model_artifacts
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
```

Test it from another terminal:

```bash
curl -X POST http://127.0.0.1:8000/api/tickets/classify \
  -H 'Content-Type: application/json' \
  -d '{"subject":"Billing issue","body":"I was charged twice for my subscription."}'
```

## Integrate into `tickets.py`

```python
from backend.app.ai.classify_ticket import classify_ticket

ai_result = classify_ticket(ticket.subject, ticket.body)
ticket.category = ai_result["category"]["label"]
ticket.priority = ai_result["priority"]["label"]
ticket.body_redacted = ai_result["body_redacted"]

needs_review = any(
    ai_result[name]["needs_human_review"]
    for name in ("category", "sentiment", "priority")
)
if needs_review:
    ticket.status = "human_review"
else:
    ticket.status = "classified"
```

Department routing and SLA deadlines must still be implemented as separate deterministic services. The model returns predictions; it does not write to Supabase or replace authentication, authorization, or database transaction handling.

## Docker deployment

After training, keep the model artifact in a private volume or artifact registry. Build the image from the repository:

```bash
docker build -t ai-support-ticket-system .
docker run --rm -p 8000:8000 \
  -e MODEL_DIR=/app/backend/app/ai/model_artifacts \
  -v "$PWD/backend/app/ai/model_artifacts:/app/backend/app/ai/model_artifacts:ro" \
  ai-support-ticket-system
```

Before public deployment, add HTTPS, JWT or service authentication, CORS restrictions, rate limiting, secrets management, monitoring, error tracking, and access controls for ticket data.

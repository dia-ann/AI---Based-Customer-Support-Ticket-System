from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .ai.classify_ticket import classify_ticket

app = FastAPI(title="AI Support Ticket System", version="1.0.0")


class TicketInput(BaseModel):
    subject: str = Field(..., min_length=1, max_length=500)
    body: str = Field(..., min_length=1, max_length=50_000)


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/tickets/classify")
def classify(ticket: TicketInput):
    try:
        return classify_ticket(ticket.subject, ticket.body)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

"""Production-friendly inference wrapper for the ticket model."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict, Iterable, List, Mapping, Optional

import torch
from transformers import AutoTokenizer

from .model import MultiTaskDistilBERT
from .pii import redact_pii


@dataclass
class TaskPrediction:
    label: str
    confidence: float
    probabilities: Dict[str, float]
    needs_human_review: bool


@dataclass
class TicketPrediction:
    subject_redacted: str
    body_redacted: str
    category: TaskPrediction
    sentiment: TaskPrediction
    priority: TaskPrediction

    def as_dict(self) -> dict:
        return asdict(self)


class TicketPredictor:
    def __init__(
        self,
        model: MultiTaskDistilBERT,
        tokenizer,
        label_maps: Mapping[str, Mapping],
        device: Optional[str] = None,
        max_length: int = 256,
        analyzer: Optional[object] = None,
        anonymizer: Optional[object] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.label_maps = label_maps
        self.max_length = max_length
        self.analyzer = analyzer
        self.anonymizer = anonymizer
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.model.to(self.device).eval()

    @classmethod
    def from_checkpoint(cls, checkpoint: str, label_maps: Mapping[str, Mapping], **kwargs):
        model = MultiTaskDistilBERT.from_ticket_pretrained(checkpoint)
        tokenizer = AutoTokenizer.from_pretrained(checkpoint)
        return cls(model, tokenizer, label_maps, **kwargs)

    def _task_prediction(self, logits: torch.Tensor, task: str) -> TaskPrediction:
        probabilities = torch.softmax(logits, dim=-1)[0].cpu().tolist()
        id_to_label = self.label_maps.get(task, {})
        if not id_to_label:
            return TaskPrediction(
                label="unavailable",
                confidence=0.0,
                probabilities={},
                needs_human_review=True,
            )
        labels = [id_to_label.get(str(i), id_to_label.get(i, str(i))) for i in range(len(probabilities))]
        best = int(torch.tensor(probabilities).argmax())
        confidence = float(probabilities[best])
        threshold = getattr(self.model.ticket_config, f"{task}_threshold")
        return TaskPrediction(
            label=labels[best],
            confidence=confidence,
            probabilities={label: float(prob) for label, prob in zip(labels, probabilities)},
            needs_human_review=confidence < threshold,
        )

    @torch.inference_mode()
    def predict(self, subject: str, body: str) -> TicketPrediction:
        redacted_subject = redact_pii(subject, analyzer=self.analyzer, anonymizer=self.anonymizer)
        redacted_body = redact_pii(body, analyzer=self.analyzer, anonymizer=self.anonymizer)
        text = f"Subject: {redacted_subject.text}\n\n{redacted_body.text}"
        encoded = self.tokenizer(
            text,
            return_tensors="pt",
            truncation=True,
            max_length=self.max_length,
        )
        encoded = {key: value.to(self.device) for key, value in encoded.items()}
        outputs = self.model(**encoded)
        return TicketPrediction(
            subject_redacted=redacted_subject.text,
            body_redacted=redacted_body.text,
            category=self._task_prediction(outputs["category_logits"], "category"),
            sentiment=self._task_prediction(outputs["sentiment_logits"], "sentiment"),
            priority=self._task_prediction(outputs["priority_logits"], "priority"),
        )

    def predict_batch(self, tickets: Iterable[Mapping[str, str]], batch_size: int = 16) -> List[TicketPrediction]:
        items = list(tickets)
        predictions: List[TicketPrediction] = []
        for start in range(0, len(items), batch_size):
            for ticket in items[start : start + batch_size]:
                predictions.append(self.predict(ticket["subject"], ticket["body"]))
        return predictions

"""Integration adapter used by backend ticket routes.

Expected environment variable:
    MODEL_DIR=backend/app/ai/model_artifacts

The checkpoint directory must contain the files created by train.py, including
`ticket_config.json`, `label_maps.json`, tokenizer files, and model weights.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional

from .inference import TicketPredictor

_predictor: Optional[TicketPredictor] = None


def get_predictor() -> TicketPredictor:
    global _predictor
    if _predictor is None:
        model_dir = Path(os.getenv("MODEL_DIR", "backend/app/ai/model_artifacts"))
        maps_file = model_dir / "label_maps.json"
        if not maps_file.exists():
            raise RuntimeError(
                f"No trained model found at {model_dir}. Run the Colab training cell first."
            )
        label_maps = json.loads(maps_file.read_text(encoding="utf-8"))
        _predictor = TicketPredictor.from_checkpoint(str(model_dir), label_maps=label_maps)
    return _predictor


def classify_ticket(subject: str, body: str) -> dict[str, Any]:
    """Return redacted text, labels, probabilities, and review flags."""
    return get_predictor().predict(subject, body).as_dict()


def reset_predictor() -> None:
    """Clear the process cache, useful after replacing model artifacts."""
    global _predictor
    _predictor = None

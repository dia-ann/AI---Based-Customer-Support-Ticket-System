"""PII redaction performed before model inference or persistence.

Presidio is supported when installed; a conservative regex fallback is always
available so classification can fail closed rather than process raw identifiers.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class RedactionResult:
    text: str
    replacements: int
    used_presidio: bool


_EMAIL = re.compile(r"\b[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+\b")
_PHONE = re.compile(r"(?<!\w)(?:\+?\d[\d\s().-]{7,}\d)(?!\w)")
_CARD = re.compile(r"(?<!\w)(?:\d[ -]*?){13,19}(?!\w)")


def _regex_redact(text: str) -> RedactionResult:
    replacements = 0

    def replace(match: re.Match[str], token: str) -> str:
        nonlocal replacements
        replacements += 1
        return token

    text = _EMAIL.sub(lambda m: replace(m, "[EMAIL]"), text)
    text = _CARD.sub(lambda m: replace(m, "[CARD_NUMBER]"), text)
    text = _PHONE.sub(lambda m: replace(m, "[PHONE]"), text)
    return RedactionResult(text=text, replacements=replacements, used_presidio=False)


def redact_pii(text: str, *, analyzer: Optional[object] = None, anonymizer: Optional[object] = None) -> RedactionResult:
    """Redact common customer identifiers.

    If configured Presidio analyzer/anonymizer instances are supplied, they are
    used first. Any Presidio failure falls back to regex redaction. Names are
    intentionally not guessed by regex because false positives can damage
    ticket meaning; configure Presidio's PERSON recognizer for name redaction.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    if analyzer is not None and anonymizer is not None:
        try:
            results = analyzer.analyze(text=text, language="en")
            anonymized = anonymizer.anonymize(text=text, analyzer_results=results)
            return RedactionResult(
                text=anonymized.text,
                replacements=len(results),
                used_presidio=True,
            )
        except Exception:
            pass
    return _regex_redact(text)

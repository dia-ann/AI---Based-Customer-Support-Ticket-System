"""Fine-tuning entry point for multi-task support-ticket classification.

Expected JSONL fields: subject, body, category, sentiment, priority.
The three label fields must be strings. Use `--allow-missing-labels` only when
training a subset of heads; missing labels are encoded as -100.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List, Mapping

import numpy as np
import torch
from torch.utils.data import Dataset
from transformers import (
    AutoTokenizer,
    DataCollatorWithPadding,
    Trainer,
    TrainingArguments,
)

from .model import MultiTaskDistilBERT, TicketModelConfig

TASKS = ("category", "sentiment", "priority")


def read_jsonl(path: str | Path) -> List[dict]:
    with Path(path).open(encoding="utf-8") as handle:
        rows = [json.loads(line) for line in handle if line.strip()]
    required = {"subject", "body"}
    if rows and not required.issubset(rows[0]):
        raise ValueError("Each row must contain subject and body")
    return rows


def build_label_maps(rows: List[dict]) -> Dict[str, Dict]:
    maps = {}
    for task in TASKS:
        labels = sorted({str(row[task]) for row in rows if row.get(task) not in (None, "")})
        maps[task] = {
            "label2id": {label: i for i, label in enumerate(labels)},
            "id2label": {str(i): label for i, label in enumerate(labels)},
        }
    return maps


class TicketDataset(Dataset):
    def __init__(self, rows: List[dict], tokenizer, label_maps: Mapping, max_length: int = 256):
        self.rows = rows
        self.tokenizer = tokenizer
        self.label_maps = label_maps
        self.max_length = max_length

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        text = f"Subject: {row['subject']}\n\n{row['body']}"
        item = self.tokenizer(text, truncation=True, max_length=self.max_length)
        for task in TASKS:
            value = row.get(task)
            item[f"{task}_labels"] = (
                self.label_maps[task]["label2id"].get(str(value), -100)
                if value not in (None, "") else -100
            )
        return item


def _accuracy_and_macro_f1(predictions: np.ndarray, labels: np.ndarray) -> tuple[float, float]:
    valid = labels != -100
    if not np.any(valid):
        return 0.0, 0.0
    y_pred, y_true = predictions[valid], labels[valid]
    accuracy = float((y_pred == y_true).mean())
    f1_values = []
    for cls in np.unique(y_true):
        tp = np.sum((y_pred == cls) & (y_true == cls))
        fp = np.sum((y_pred == cls) & (y_true != cls))
        fn = np.sum((y_pred != cls) & (y_true == cls))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1_values.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return accuracy, float(np.mean(f1_values))


def compute_metrics(eval_prediction):
    predictions, labels = eval_prediction
    if isinstance(predictions, tuple):
        predictions = predictions[:3]
    if isinstance(labels, tuple):
        labels = labels[:3]
    result = {}
    for task, logits, target in zip(TASKS, predictions, labels):
        accuracy, macro_f1 = _accuracy_and_macro_f1(np.argmax(logits, axis=-1), target)
        result[f"{task}_accuracy"] = accuracy
        result[f"{task}_macro_f1"] = macro_f1
    result["mean_macro_f1"] = float(np.mean([result[f"{task}_macro_f1"] for task in TASKS]))
    return result


def train(args) -> None:
    train_rows = read_jsonl(args.train_file)
    eval_rows = read_jsonl(args.eval_file)
    label_maps = build_label_maps(train_rows)
    ticket_config = TicketModelConfig(
        backbone=args.backbone,
        num_categories=max(1, len(label_maps["category"]["label2id"])),
        num_sentiments=max(1, len(label_maps["sentiment"]["label2id"])),
        num_priorities=max(1, len(label_maps["priority"]["label2id"])),
    )
    tokenizer = AutoTokenizer.from_pretrained(args.backbone)
    model = MultiTaskDistilBERT.from_backbone(ticket_config)
    train_dataset = TicketDataset(train_rows, tokenizer, label_maps, args.max_length)
    eval_dataset = TicketDataset(eval_rows, tokenizer, label_maps, args.max_length)
    collator = DataCollatorWithPadding(tokenizer=tokenizer)
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        learning_rate=args.learning_rate,
        per_device_train_batch_size=args.train_batch_size,
        per_device_eval_batch_size=args.eval_batch_size,
        num_train_epochs=args.epochs,
        weight_decay=args.weight_decay,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="mean_macro_f1",
        greater_is_better=True,
        report_to="none",
    )
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        processing_class=tokenizer,
        data_collator=collator,
        compute_metrics=compute_metrics,
    )
    trainer.train()
    model.save_ticket_pretrained(args.output_dir, label_maps)
    tokenizer.save_pretrained(args.output_dir)
    (Path(args.output_dir) / "training_args.json").write_text(
        json.dumps(vars(args), indent=2), encoding="utf-8"
    )


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-file", required=True)
    parser.add_argument("--eval-file", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--backbone", default="distilbert/distilbert-base-uncased")
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--train-batch-size", type=int, default=16)
    parser.add_argument("--eval-batch-size", type=int, default=16)
    parser.add_argument("--epochs", type=float, default=3.0)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    return parser.parse_args()


if __name__ == "__main__":
    train(parse_args())

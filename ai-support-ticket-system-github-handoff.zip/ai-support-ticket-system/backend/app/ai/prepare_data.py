"""Prepare uploaded and optional public support data for DistilBERT training.

The uploaded files are the primary data sources. BANKING77 is optional and is
kept in a source-aware namespace because its 77 intents are not identical to
the uploaded category labels. Missing priority and sentiment labels remain
missing; this script never fabricates them.
"""
from __future__ import annotations

import argparse
import csv
import json
import random
from pathlib import Path
from typing import Iterable


def load_json(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError(f"Expected a JSON list in {path}")
    return data


def normalize_uploaded(rows: Iterable[dict], source: str) -> list[dict]:
    normalized = []
    for row in rows:
        subject = str(row.get("subject") or "").strip()
        body = str(row.get("body") or "").strip()
        category = str(row.get("category") or "").strip()
        priority = str(row.get("priority") or "").strip()
        if not subject or not body or not category:
            continue
        item = {
            "subject": subject,
            "body": body,
            "category": f"{source}::{category}",
            "priority": priority or None,
            "source_dataset": source,
            "sub_category": row.get("sub_category"),
            "channel": row.get("channel"),
        }
        normalized.append(item)
    return normalized


def load_banking77(directory: Path | None = None) -> list[dict]:
    rows = []
    if directory is not None and (directory / "train.csv").exists():
        files = sorted(directory.glob("*.csv"))
        for path in files:
            with path.open(encoding="utf-8", newline="") as handle:
                for row in csv.DictReader(handle):
                    rows.append({
                        "subject": "Banking customer query",
                        "body": str(row["text"]),
                        "category": f"banking77::{row['category']}",
                        "priority": None,
                        "source_dataset": "banking77",
                        "sub_category": None,
                        "channel": "public_dataset",
                    })
        return rows
    from datasets import load_dataset
    dataset = load_dataset("PolyAI/banking77")
    label_names = dataset["train"].features["label"].names
    for split in dataset.values():
        for row in split:
            intent = label_names[int(row["label"])]
            rows.append({
                "subject": "Banking customer query",
                "body": str(row["text"]),
                "category": f"banking77::{intent}",
                "priority": None,
                "source_dataset": "banking77",
                "sub_category": None,
                "channel": "public_dataset",
            })
    return rows


def write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tickets", type=Path, required=True)
    parser.add_argument("--support-tickets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--add-banking77", action="store_true")
    parser.add_argument("--banking77-dir", type=Path)
    parser.add_argument("--validation-ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if not 0.05 <= args.validation_ratio <= 0.5:
        raise ValueError("validation ratio must be between 0.05 and 0.5")

    rows = normalize_uploaded(load_json(args.tickets), "consumer_finance")
    rows += normalize_uploaded(load_json(args.support_tickets), "product_support")
    if args.add_banking77:
        rows += load_banking77(args.banking77_dir)

    unique = {}
    for row in rows:
        key = (row["subject"], row["body"], row["category"])
        unique[key] = row
    rows = list(unique.values())
    rng = random.Random(args.seed)
    grouped = {}
    for row in rows:
        grouped.setdefault(row["category"], []).append(row)
    train, valid = [], []
    for group in grouped.values():
        rng.shuffle(group)
        split_at = max(1, int(len(group) * (1 - args.validation_ratio)))
        split_at = min(split_at, max(1, len(group) - 1)) if len(group) > 1 else 1
        train.extend(group[:split_at])
        valid.extend(group[split_at:])
    rng.shuffle(train)
    rng.shuffle(valid)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(args.output_dir / "train.jsonl", train)
    write_jsonl(args.output_dir / "valid.jsonl", valid)
    summary = {
        "total": len(rows),
        "train": len(train),
        "valid": len(valid),
        "banking77_added": args.add_banking77,
        "category_labels": sorted({row["category"] for row in rows}),
        "priority_labels": sorted({row["priority"] for row in rows if row["priority"]}),
        "missing_priority": sum(row["priority"] is None for row in rows),
    }
    (args.output_dir / "dataset_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

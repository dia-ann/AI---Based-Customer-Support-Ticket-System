# Dataset report

## Sources used

The rebuild uses the two supplied JSON datasets as primary sources. `tickets.json` contains 5,000 consumer-finance complaint records with eight categories and four priority labels. `support_tickets(1).json` contains 8,077 product-support records with five categories and four priority labels. The official PolyAI Banking77 repository contributes 13,083 English banking customer-service queries with 77 fine-grained intent categories; the source is described by the Hugging Face dataset card at [PolyAI/banking77](https://huggingface.co/datasets/PolyAI/banking77) and the original source files are downloaded from [PolyAI-LDN/task-specific-datasets](https://github.com/PolyAI-LDN/task-specific-datasets).

## Normalization policy

The two uploaded datasets are normalized into `subject`, `body`, `category`, `priority`, `source_dataset`, `sub_category`, and `channel`. Category labels are namespaced to prevent collisions: consumer-finance labels become `consumer_finance::...`, product-support labels become `product_support::...`, and Banking77 intents become `banking77::...`. The preparation script removes duplicate subject/body/category records and performs a category-stratified train/validation split.

Priority labels are preserved only where the source provides them. Banking77 has no priority annotation, so its 13,083 records retain a missing priority label and do not contribute to the priority loss. Neither uploaded dataset provides ground-truth sentiment labels, so sentiment is optional and is reported as unavailable unless a future labeled sentiment dataset is added. The code never fabricates sentiment or priority labels.

## Generated combined dataset

The generated `data/combined_with_banking77` dataset contains 26,151 unique records: 20,880 training records and 5,271 validation records. It contains 90 source-aware category labels and four priority labels. There are 13,083 records with missing priority, corresponding to Banking77. The generated summary is stored in `data/combined_with_banking77/dataset_summary.json`.

## Model consequence

The primary category head learns a source-aware 90-class taxonomy. The priority head learns four classes from the two uploaded datasets. The sentiment head is retained for future labeled data but is skipped during loss computation when all sentiment labels are missing; inference reports sentiment as `unavailable` and forces human review rather than returning an unsupported guess.

## Important quality caveat

The product-support file contains synthetic/template-like and occasionally mismatched text, while the consumer-finance data is domain-specific and heavily imbalanced. The code therefore reports macro-F1, preserves source namespaces, and exposes confidence thresholds. Before production routing, evaluate separately by source dataset and category, review false positives, and calibrate thresholds on a held-out, de-identified sample from the actual organization.

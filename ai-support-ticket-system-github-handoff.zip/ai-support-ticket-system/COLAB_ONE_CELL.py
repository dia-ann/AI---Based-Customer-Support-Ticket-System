# Paste this entire cell into Google Colab.
# Required uploads: tickets.json and support_tickets(1).json.
# Optional public augmentation: official PolyAI Banking77 is downloaded automatically.
# Enable a GPU in Runtime > Change runtime type when available.

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

subprocess.check_call([
    sys.executable, '-m', 'pip', 'install', '-q',
    'torch', 'transformers', 'fastapi', 'uvicorn[standard]', 'numpy', 'requests'
])

from google.colab import files

print('Upload tickets.json and support_tickets(1).json')
uploaded = files.upload()
required = ('tickets.json', 'support_tickets(1).json')
for filename in required:
    if filename not in uploaded:
        raise RuntimeError(f'You must upload {filename}')

PROJECT = Path('/content/ai-support-ticket-system')
if not PROJECT.exists():
    raise RuntimeError('Extract or upload the ai-support-ticket-system project before running this cell.')
os.chdir(PROJECT)
Path('data/uploads').mkdir(parents=True, exist_ok=True)
shutil.copy('/content/tickets.json', 'data/uploads/tickets.json')
shutil.copy('/content/support_tickets(1).json', 'data/uploads/support_tickets(1).json')

# Download the official PolyAI Banking77 CSV files from the source repository.
banking_dir = Path('data/banking77')
banking_dir.mkdir(parents=True, exist_ok=True)
for filename in ('train.csv', 'test.csv'):
    url = f'https://raw.githubusercontent.com/PolyAI-LDN/task-specific-datasets/master/banking_data/{filename}'
    urllib.request.urlretrieve(url, banking_dir / filename)

# Normalize both uploaded files and Banking77 with source-aware category labels.
subprocess.check_call([
    sys.executable, '-m', 'backend.app.ai.prepare_data',
    '--tickets', 'data/uploads/tickets.json',
    '--support-tickets', 'data/uploads/support_tickets(1).json',
    '--banking77-dir', str(banking_dir),
    '--add-banking77',
    '--output-dir', 'data/combined',
])

artifact_dir = PROJECT / 'backend' / 'app' / 'ai' / 'model_artifacts'
artifact_dir.mkdir(parents=True, exist_ok=True)
subprocess.check_call([
    sys.executable, '-m', 'backend.app.ai.train',
    '--train-file', 'data/combined/train.jsonl',
    '--eval-file', 'data/combined/valid.jsonl',
    '--output-dir', str(artifact_dir),
    '--epochs', '3',
    '--train-batch-size', '16',
    '--eval-batch-size', '16',
    '--max-length', '256',
])

os.environ['MODEL_DIR'] = str(artifact_dir.resolve())
sys.path.insert(0, str(PROJECT))
from backend.app.ai.classify_ticket import classify_ticket, reset_predictor
reset_predictor()
print('Direct prediction:')
print(classify_ticket(
    'Cannot sign in',
    'The password reset link expired. Please help.',
))

api_log = open('/tmp/support-ticket-api.log', 'w')
api_process = subprocess.Popen([
    sys.executable, '-m', 'uvicorn', 'backend.app.main:app',
    '--host', '0.0.0.0', '--port', '8000'
], cwd=PROJECT, env=os.environ.copy(), stdout=api_log, stderr=api_log)
time.sleep(8)
import requests
health = requests.get('http://127.0.0.1:8000/health', timeout=20)
print('API health:', health.status_code, health.json())
response = requests.post(
    'http://127.0.0.1:8000/api/tickets/classify',
    json={'subject': 'Billing issue', 'body': 'I was charged twice for my subscription.'},
    timeout=60,
)
print('API prediction:', response.status_code, response.json())
print('API running at http://127.0.0.1:8000')

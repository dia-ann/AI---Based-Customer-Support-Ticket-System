# Direct copy-paste Google Colab code

This is the exact sequence to paste into Colab. It follows the requested structure: `backend/app/ai/redact_pii.py`, `backend/app/ai/model.py`, `backend/app/ai/inference.py`, `backend/app/ai/classify_ticket.py`, and `backend/app/main.py`.

## Cell 1 — install dependencies

```python
!pip -q install torch transformers fastapi 'uvicorn[standard]' numpy pytest
```

## Cell 2 — upload the prepared project archive

Upload the delivered `ai-support-ticket-system.zip` archive.

```python
from google.colab import files
import zipfile, os

uploaded = files.upload()
zip_name = next(name for name in uploaded if name.endswith('.zip'))
with zipfile.ZipFile(zip_name) as z:
    z.extractall('/content')
os.chdir('/content/ai-support-ticket-system')
```

The archive supplied with this guide is already arranged in the requested backend structure and contains the trainer under `backend/app/ai/train.py`.

## Cell 3 — upload your de-identified labeled data

Upload two files named `train.jsonl` and `valid.jsonl`. Every row must contain `subject`, `body`, `category`, `sentiment`, and `priority`.

```python
from google.colab import files
import os, shutil

uploaded = files.upload()
os.makedirs('data', exist_ok=True)
for filename in ('train.jsonl', 'valid.jsonl'):
    if filename not in uploaded:
        raise FileNotFoundError(f'Upload {filename}')
    shutil.copy('/content/ai-support-ticket-system/' + filename, 'data/' + filename) if os.path.exists('/content/ai-support-ticket-system/' + filename) else shutil.copy('/content/' + filename, 'data/' + filename)
```

Example row format only:

```json
{"subject":"Cannot sign in","body":"My reset link expired.","category":"account_access","sentiment":"negative","priority":"high"}
```

Do not train on real names, email addresses, phone numbers, card numbers, passwords, or other sensitive data. Redaction at inference is included, but the training data must also be de-identified.

## Cell 4 — train the model

```python
!mkdir -p /content/ai-support-ticket-system/backend/app/ai/model_artifacts
!python -m backend.app.ai.train \
  --train-file /content/ai-support-ticket-system/data/train.jsonl \
  --eval-file /content/ai-support-ticket-system/data/valid.jsonl \
  --output-dir /content/ai-support-ticket-system/backend/app/ai/model_artifacts \
  --epochs 3 \
  --train-batch-size 16 \
  --eval-batch-size 16 \
  --max-length 256
```

The model is not meaningful before this step because a generic pretrained DistilBERT checkpoint does not know your organization’s ticket categories, sentiment labels, or priorities. After this step, the artifact directory contains trained weights, tokenizer files, configuration, and label maps.

## Cell 6 — test the exact backend classifier

```python
import sys, os
sys.path.insert(0, '/content/ai-support-ticket-system')
os.environ['MODEL_DIR'] = '/content/ai-support-ticket-system/backend/app/ai/model_artifacts'

from backend.app.ai.classify_ticket import classify_ticket

result = classify_ticket(
    'Cannot sign in',
    'The password reset link expired. Please help.',
)
result
```

The result includes category, sentiment, and priority predictions, probabilities, confidence scores, `needs_human_review` flags, and redacted text.

## Cell 7 — start the deployable API

```python
!cd /content/ai-support-ticket-system && \
  MODEL_DIR=/content/ai-support-ticket-system/backend/app/ai/model_artifacts \
  nohup uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 \
  > /tmp/support-ticket-api.log 2>&1 &
```

```python
import requests, time
for _ in range(15):
    try:
        print(requests.get('http://127.0.0.1:8000/health').json())
        break
    except Exception:
        time.sleep(2)
```

```python
requests.post(
    'http://127.0.0.1:8000/api/tickets/classify',
    json={
        'subject': 'Billing issue',
        'body': 'I was charged twice for my subscription.'
    },
).json()
```

## Production deployment command

After training, copy the complete project and the generated `backend/app/ai/model_artifacts/` directory to your server. Then run:

```bash
cd ai-support-ticket-system
python -m venv .venv
source .venv/bin/activate
pip install torch transformers fastapi 'uvicorn[standard]' numpy
export MODEL_DIR=backend/app/ai/model_artifacts
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
```

For a container deployment, use the supplied Dockerfile after copying the trained artifact directory into the project. Add HTTPS, authentication/JWT, rate limiting, structured logging, secret management, monitoring, and a reverse proxy before exposing the endpoint publicly.

## Direct integration call from `tickets.py`

```python
from backend.app.ai.classify_ticket import classify_ticket

ai_result = classify_ticket(ticket.subject, ticket.body)
if (
    ai_result['category']['needs_human_review']
    or ai_result['sentiment']['needs_human_review']
    or ai_result['priority']['needs_human_review']
):
    ticket.status = 'human_review'
else:
    ticket.status = 'classified'
# Use ai_result['category']['label'] for your deterministic category-to-department lookup.
# Use ai_result['priority']['label'] for your deterministic SLA policy lookup.
```

The model itself does not create replies, perform SLA arithmetic, route departments, write to Supabase, or change ticket states. Those operations belong in the surrounding services shown in your requested project structure.
